# JkPackager

JkPackager is a Python library for packaging Python scripts into executable formats like `.exe`, `.pkg`, `.deb`, and `.rpm`.

## Installation

```bash
pip install jkpackager
